package com.archive.susu.test;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SusuModel {
    private String name;
}
